At the bash prompt, type

compass watch

and the css file will get updated in the parallel directory