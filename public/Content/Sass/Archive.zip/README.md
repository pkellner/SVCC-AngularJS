to regenerate css files, while 'compass watch' is running please
- 'touch _site-svcc.scss' to regenerate SVCC site styles
- 'touch _site-cssc.scss' to regenerate CSSC site styles
